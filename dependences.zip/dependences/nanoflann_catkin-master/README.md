Catkin wrapper of https://github.com/jlblancoc/nanoflann
