# cmake_external_project_catkin
macros that help to make ExternalProject dependencies install and build correctly when used with catkin devel and install locations
