yaml_cpp_catkin
===============

Yaml cpp catkin package
