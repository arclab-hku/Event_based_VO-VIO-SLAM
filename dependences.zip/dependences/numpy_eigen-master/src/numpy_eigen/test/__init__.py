from __future__ import print_function

import os
print('Importing numpy_test ', os.path.realpath(__file__))
from ..libnumpy_eigen_test import *
