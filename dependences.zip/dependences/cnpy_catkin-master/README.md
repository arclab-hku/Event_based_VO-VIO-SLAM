cnpy_catkin
=============

A catkin wrapper for [cnpy](https://github.com/rogersce/cnpy).
